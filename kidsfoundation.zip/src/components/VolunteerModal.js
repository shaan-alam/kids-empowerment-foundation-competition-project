import Modal from "./Modal"

const AuthAlert = () => {}

const VolunteerModal = () => {
  return (
    <Modal>
      <div className="modal__content">

      </div>
    </Modal>
  )
}

export default VolunteerModal