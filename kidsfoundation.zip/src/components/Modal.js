const Modal = ({ children }) => {
  return <div className="modal__backdrop">{children}</div>;
};

export default Modal;
